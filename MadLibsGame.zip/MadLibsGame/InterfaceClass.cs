﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MadLibsGame
{
    class InterfaceClass
    {
        interface MadInterface
        {
            static string noun;
            static string verb;
            static string adjictive;
            static string adverb;
            static string preposition;
            static string noun2;
            static string madLib;


        }
    }
}
